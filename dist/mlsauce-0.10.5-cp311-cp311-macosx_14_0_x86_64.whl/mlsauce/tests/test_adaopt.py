#!/usr/bin/env python

"""Tests for `mlsauce` package."""


import unittest

from mlsauce import mlsauce


class Testmlsauce(unittest.TestCase):
    """Tests for `mlsauce` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
